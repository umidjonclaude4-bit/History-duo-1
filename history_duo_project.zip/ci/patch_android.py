#!/usr/bin/env python3
"""flutter create yaratgan android/ papkasini HISTORY DUO uchun sozlaydi."""
import pathlib, re, sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".")
man = root / "android/app/src/main/AndroidManifest.xml"
s = man.read_text(encoding="utf-8")

if "xmlns:tools" not in s:
    s = s.replace("<manifest ", '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)

perms = [
    '<uses-permission android:name="android.permission.INTERNET"/>',
    '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>',
    '<uses-permission android:name="android.permission.CHANGE_NETWORK_STATE"/>',
    '<uses-permission android:name="android.permission.RECORD_AUDIO"/>',
    '<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>',
    '<uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>',
    '<uses-permission android:name="android.permission.CAMERA" tools:node="remove"/>',
]
block = "".join("    %s\n" % p for p in perms if p not in s)
if block:
    s = s.replace("<application", block + "    <application", 1)

s = re.sub(r'(<application[^>]*?android:label=")[^"]*(")', r"\1HISTORY DUO\2", s, count=1, flags=re.S)
if "HISTORY DUO" not in s:
    sys.exit("XATO: ilova nomini o'rnatib bo'lmadi")
man.write_text(s, encoding="utf-8")

# minSdk >= 24 (Firebase + WebRTC uchun)
gradle = None
for n in ("build.gradle.kts", "build.gradle"):
    p = root / "android/app" / n
    if p.exists():
        gradle = p
        break
if gradle is None:
    sys.exit("XATO: android/app/build.gradle topilmadi")
g = gradle.read_text(encoding="utf-8")
g2, n1 = re.subn(r"minSdk(Version)?(\s*=\s*|\s+)flutter\.minSdkVersion", lambda m: "minSdk%s%s24" % (m.group(1) or "", m.group(2)), g)
if n1 == 0:
    g2, n2 = re.subn(r"minSdk(Version)?(\s*=\s*|\s+)(\d+)", lambda m: "minSdk%s%s%d" % (m.group(1) or "", m.group(2), max(24, int(m.group(3)))), g)
    if n2 == 0:
        sys.exit("XATO: minSdk qatori topilmadi")
gradle.write_text(g2, encoding="utf-8")
print("OK: manifest va minSdk sozlandi (%s)" % gradle.name)
