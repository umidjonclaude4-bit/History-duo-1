/// WebRTC uchun STUN/TURN sozlamalari.
/// STUN (Google) har doim yoqilgan. TURN ixtiyoriy, lekin mobil tarmoqda
/// ~15-20% foydalanuvchi uchun kerak bo'ladi. Quyidagilardan BIRINI to'ldiring.
class IceConfig {
  // 1-variant: Metered.ca (bepul tarif). metered.ca da ro'yxatdan o'ting,
  // ilova nomi (xxx.metered.live dagi "xxx") va API kalitni yozing.
  static const meteredApp = String.fromEnvironment('METERED_APP');
  static const meteredKey = String.fromEnvironment('METERED_KEY');

  // 2-variant: o'z TURN serveringiz (masalan coturn).
  static const turnUrl = String.fromEnvironment('TURN_URL'); // masalan: turn:turn.example.com:3478
  static const turnUsername = String.fromEnvironment('TURN_USERNAME');
  static const turnCredential = String.fromEnvironment('TURN_CREDENTIAL');
}
