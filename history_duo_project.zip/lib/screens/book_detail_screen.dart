import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/book.dart';
import '../services/auth_service.dart';
import '../services/book_service.dart';
import '../widgets/confirm_dialog.dart';
import 'add_topic_screen.dart';
import 'topic_screen.dart';

class BookDetailScreen extends StatelessWidget {
  final Book book;
  final bool pickMode;
  const BookDetailScreen({super.key, required this.book, this.pickMode = false});

  @override
  Widget build(BuildContext context) {
    if (!book.isCustom) return _content(context, book);
    return StreamBuilder<Book?>(
      stream: BookService.instance.bookStream(book.id),
      builder: (context, snap) => _content(context, snap.data ?? book),
    );
  }

  Future<void> _deleteBook(BuildContext context, Book b) async {
    final ok = await confirmDialog(context,
        title: "Kitobni o'chirish",
        message: "\"${b.title}\" va uning barcha mavzulari o'chiriladi.",
        confirmLabel: "O'chirish");
    if (!ok || !context.mounted) return;
    final nav = Navigator.of(context);
    try {
      await BookService.instance.deleteBook(b.id);
      nav.pop();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
  }

  Future<void> _deleteTopic(BuildContext context, Book b, Topic t) async {
    final ok = await confirmDialog(context,
        title: "Mavzuni o'chirish",
        message: "\"${t.title}\" o'chiriladi.",
        confirmLabel: "O'chirish");
    if (!ok || !context.mounted) return;
    try {
      await BookService.instance.deleteTopic(b, t.id);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
  }

  void _addTopic(BuildContext context, Book b) {
    Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => AddTopicScreen(book: b)));
  }

  Widget _content(BuildContext context, Book b) {
    final canEdit = b.isCustom && !pickMode;
    return Scaffold(
      appBar: AppBar(
        title: Text(b.title),
        actions: [
          if (canEdit)
            IconButton(
              tooltip: "Mavzu qo'shish",
              icon: const Icon(Icons.add_rounded, color: AppColors.gold),
              onPressed: () => _addTopic(context, b),
            ),
          if (canEdit)
            IconButton(
              tooltip: "Kitobni o'chirish",
              icon: const Icon(Icons.delete_outline_rounded),
              onPressed: () => _deleteBook(context, b),
            ),
        ],
      ),
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: b.topics.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.library_books_rounded,
                            size: 64, color: AppColors.gold),
                        const SizedBox(height: 16),
                        const Text("Bu kitobda hali mavzu yo'q",
                            style: TextStyle(fontSize: 17)),
                        if (canEdit) ...[
                          const SizedBox(height: 16),
                          FilledButton.icon(
                            style: FilledButton.styleFrom(
                                backgroundColor: AppColors.gold,
                                foregroundColor: AppColors.black),
                            onPressed: () => _addTopic(context, b),
                            icon: const Icon(Icons.add_rounded),
                            label: const Text("Mavzu qo'shish"),
                          ),
                        ],
                      ],
                    ),
                  ),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
                  children: [
                    if (pickMode)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 12),
                        child: Text("O'rganmoqchi bo'lgan mavzuni tanlang",
                            style: TextStyle(color: AppColors.textDim)),
                      ),
                    for (final t in b.topics) _topicTile(context, b, t, canEdit),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _topicTile(BuildContext context, Book b, Topic t, bool canEdit) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: AppColors.navy,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () {
            if (pickMode) {
              Navigator.of(context).pop(TopicSelection(b, t));
            } else {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => TopicScreen(book: b, topic: t)));
            }
          },
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.goldBorder),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(t.title,
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text("${t.sections.length} ta bo'lim",
                          style: const TextStyle(
                              color: AppColors.textDim, fontSize: 13)),
                    ],
                  ),
                ),
                if (pickMode)
                  const Icon(Icons.check_circle_outline_rounded,
                      color: AppColors.gold)
                else if (canEdit)
                  IconButton(
                    icon: const Icon(Icons.delete_outline_rounded,
                        color: AppColors.textDim),
                    onPressed: () => _deleteTopic(context, b, t),
                  )
                else
                  const Icon(Icons.chevron_right_rounded,
                      color: AppColors.textDim),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
