import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'auth_screen.dart';
import 'home_screen.dart';

/// Kirgan foydalanuvchi -> Bosh sahifa, aks holda -> Kirish ekrani.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
                child: CircularProgressIndicator(color: AppColors.gold)),
          );
        }
        return snap.hasData ? const HomeScreen() : const AuthScreen();
      },
    );
  }
}
