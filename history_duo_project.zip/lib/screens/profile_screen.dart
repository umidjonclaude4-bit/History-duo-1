import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _snack(BuildContext context, String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _editName(BuildContext context, String current) async {
    final c = TextEditingController(text: current);
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.navy,
        title: const Text("Ismni o'zgartirish"),
        content: TextField(controller: c, maxLength: 24, autofocus: true),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("Bekor qilish")),
          TextButton(
              onPressed: () => Navigator.pop(ctx, c.text.trim()),
              child: const Text("Saqlash")),
        ],
      ),
    );
    if (res == null || res.length < 2) return;
    try {
      await AuthService.instance.updateName(res);
    } catch (e) {
      if (context.mounted) _snack(context, friendlyError(e));
    }
  }

  Future<void> _signOut(BuildContext context) async {
    final nav = Navigator.of(context);
    nav.popUntil((r) => r.isFirst);
    await AuthService.instance.signOut();
  }

  Future<void> _deleteAccount(BuildContext context) async {
    final c = TextEditingController();
    final pass = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.navy,
        title: const Text("Hisobni o'chirish"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Hisobingiz va barcha ma'lumotlaringiz butunlay o'chiriladi. "
              "Tasdiqlash uchun parolingizni kiriting.",
              style: TextStyle(color: AppColors.textDim),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: c,
              obscureText: true,
              decoration: const InputDecoration(labelText: "Parol"),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("Bekor qilish")),
          TextButton(
              onPressed: () => Navigator.pop(ctx, c.text),
              child: const Text("O'chirish",
                  style: TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    if (pass == null || pass.isEmpty) return;
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    try {
      await AuthService.instance.deleteAccount(pass);
      nav.popUntil((r) => r.isFirst);
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(friendlyError(e))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Scaffold();

    return Scaffold(
      appBar: AppBar(title: const Text("Profil va sozlamalar")),
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .doc(user.uid)
                .snapshots(),
            builder: (context, snap) {
              final data = snap.data?.data();
              final name =
                  (data?['displayName'] ?? user.displayName ?? '') as String;
              final age = data?['ageGroup'] == 'teen'
                  ? "13–17 yosh"
                  : "18 va undan katta";
              return ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  const SizedBox(height: 10),
                  Center(
                    child: CircleAvatar(
                      radius: 46,
                      backgroundColor: AppColors.navyLight,
                      child: Text(
                        name.isEmpty ? '?' : name[0].toUpperCase(),
                        style: const TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w800,
                            color: AppColors.gold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Center(
                    child: Text(name,
                        style: const TextStyle(
                            fontSize: 22, fontWeight: FontWeight.w800)),
                  ),
                  const SizedBox(height: 4),
                  Center(
                    child: Text(user.email ?? '',
                        style: const TextStyle(color: AppColors.textDim)),
                  ),
                  const SizedBox(height: 24),
                  _tile(Icons.cake_rounded, "Yosh guruhi", age),
                  _action(Icons.edit_rounded, "Ismni o'zgartirish",
                      () => _editName(context, name)),
                  _action(Icons.logout_rounded, "Chiqish",
                      () => _signOut(context)),
                  _action(Icons.delete_forever_rounded, "Hisobni o'chirish",
                      () => _deleteAccount(context),
                      color: Colors.redAccent),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _tile(IconData icon, String title, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.navy,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.goldBorder),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppColors.gold),
          const SizedBox(width: 14),
          Text(title, style: const TextStyle(color: AppColors.textDim)),
          const Spacer(),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _action(IconData icon, String title, VoidCallback onTap,
      {Color color = AppColors.textMain}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: AppColors.navy,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppColors.goldBorder),
            ),
            child: Row(
              children: [
                Icon(icon, color: color == AppColors.textMain
                    ? AppColors.gold
                    : color),
                const SizedBox(width: 14),
                Text(title,
                    style: TextStyle(
                        color: color, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
