import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import '../services/match_service.dart';
import '../services/voice_service.dart';
import '../services/study_round_service.dart';
import '../services/safety_service.dart';
import '../widgets/confirm_dialog.dart';

/// Ikki kishilik xona + ovozli aloqa. (Roundlar - 6-bosqich.)
class RoomScreen extends StatefulWidget {
  final String roomId;
  const RoomScreen({super.key, required this.roomId});

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  final String _uid = FirebaseAuth.instance.currentUser!.uid;
  late final DocumentReference<Map<String, dynamic>> _ref =
      FirebaseFirestore.instance.collection('rooms').doc(widget.roomId);
  bool _leaving = false;
  VoiceService? _voice;
  int? _startedAttempt;
  String? _savedCompletedRoom;

  @override
  void initState() {
    super.initState();
    MatchService.instance.enterRoom(widget.roomId).catchError((_) {});
  }

  @override
  void dispose() {
    _voice?.dispose();
    super.dispose();
  }

  void _syncVoice(List<String> parts, int attempt) {
    _voice ??= VoiceService(roomId: widget.roomId, isCaller: parts[0] == _uid);
    if (_startedAttempt != attempt) {
      _startedAttempt = attempt;
      final v = _voice!;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) v.start(attempt);
      });
    }
  }

  Future<void> _reconnect() async {
    try {
      await _ref.update({'voiceAttempt': FieldValue.increment(1)});
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
  }

  Future<void> _confirmEnd() async {
    final ok = await confirmDialog(context,
        title: "Suhbatni tugatish",
        message: "Aloqa uziladi va sherigingiz ham xonadan chiqariladi.",
        confirmLabel: "Tugatish");
    if (!ok || !mounted) return;
    try {
      await MatchService.instance.endRoom(widget.roomId);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
  }

  Future<void> _handleEnded(bool mine) async {
    _voice?.dispose();
    _voice = null;
    if (!mine && mounted) {
      await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppColors.navy,
          title: const Text("Suhbat tugadi"),
          content: const Text("Sherigingiz suhbatni tugatdi."),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx), child: const Text("OK")),
          ],
        ),
      );
    }
    await MatchService.instance.leaveRoom(widget.roomId);
    if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmEnd();
      },
      child: Scaffold(
        appBar: AppBar(
            title: const Text("Xona"), automaticallyImplyLeading: false),
        body: Container(
          decoration: appBackground,
          child: SafeArea(
            child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              stream: _ref.snapshots(),
              builder: (context, snap) {
                if (snap.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(friendlyError(snap.error!),
                              textAlign: TextAlign.center),
                          const SizedBox(height: 16),
                          FilledButton(
                            onPressed: () => _handleEnded(true),
                            child: const Text("Chiqish"),
                          ),
                        ],
                      ),
                    ),
                  );
                }
                final d = snap.data?.data();
                if (d == null) {
                  return const Center(
                      child:
                          CircularProgressIndicator(color: AppColors.gold));
                }
                if (d['status'] == 'ended') {
                  if (!_leaving) {
                    _leaving = true;
                    final mine = d['endedBy'] == _uid;
                    WidgetsBinding.instance
                        .addPostFrameCallback((_) => _handleEnded(mine));
                  }
                  return const Center(
                      child:
                          CircularProgressIndicator(color: AppColors.gold));
                }
                return _body(d);
              },
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _saveMyResult(Map<String, dynamic> room) async {
    try {
      final parts = List<String>.from(room['participants'] as List);
      if (!parts.contains(_uid)) return;
      final partner = parts.firstWhere((p) => p != _uid);
      final names = Map<String, dynamic>.from(room['names'] as Map? ?? {});
      final scores = Map<String, dynamic>.from(room['scores'] as Map? ?? {});
      final pick = Map<String, dynamic>.from(room['sharedPick'] as Map? ?? {});
      final sections = (pick['sections'] as List?) ?? const [];
      await FirebaseFirestore.instance.collection('users').doc(_uid)
          .collection('sessions').doc(widget.roomId).set({
        'roomId': widget.roomId,
        'partnerUid': partner,
        'partnerName': names[partner] ?? 'Sherik',
        'myScore': (scores[_uid] as num?)?.toInt() ?? 0,
        'partnerScore': (scores[partner] as num?)?.toInt() ?? 0,
        'sectionCount': sections.length,
        'bookTitle': pick['bookTitle'] ?? '',
        'topicTitle': pick['topicTitle'] ?? '',
        'completedAt': room['completedAt'] ?? FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {
      _savedCompletedRoom = null;
    }
  }

  Future<void> _partnerSafetyAction(String action, String partnerUid, String partnerName) async {
    if (action == 'report') {
      const reasons = ['Haqorat yoki bezovta qilish', 'Nomaqbul gaplar', 'Boshqa xavfsizlik muammosi'];
      final reason = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.navy,
        title: const Text('Shikoyat sababi'),
        content: Column(mainAxisSize: MainAxisSize.min, children: reasons.map((r) => ListTile(title: Text(r), onTap: () => Navigator.pop(ctx, r))).toList()),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Bekor qilish'))],
      ));
      if (reason == null) return;
      try {
        await SafetyService.instance.reportUser(otherUid: partnerUid, roomId: widget.roomId, reason: reason);
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Shikoyat yuborildi.')));
      } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(friendlyError(e)))); }
      return;
    }
    final ok = await confirmDialog(context, title: 'Bloklash', message: '$partnerName bloklansinmi? Keyingi tasodifiy qidiruvlarda bir-biringizga mos kelmaysiz.', confirmLabel: 'Bloklash');
    if (!ok) return;
    try {
      await SafetyService.instance.blockUser(partnerUid);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Foydalanuvchi bloklandi.')));
      await MatchService.instance.endRoom(widget.roomId);
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(friendlyError(e)))); }
  }

  Widget _body(Map<String, dynamic> d) {
    final parts = List<String>.from(d['participants'] as List);
    final attempt = (d['voiceAttempt'] ?? 0) as int;
    _syncVoice(parts, attempt);

    final partner = parts.firstWhere((p) => p != _uid, orElse: () => '');
    final names = Map<String, dynamic>.from(d['names'] as Map);
    final picks = Map<String, dynamic>.from(d['picks'] as Map);
    final joined = d['joined'] is Map
        ? Map<String, dynamic>.from(d['joined'] as Map)
        : <String, dynamic>{};
    final pName = (names[partner] ?? 'Sherik') as String;
    final mine = Map<String, dynamic>.from(picks[_uid] as Map);
    final theirs = Map<String, dynamic>.from(picks[partner] as Map);
    final partnerIn = joined[partner] == true;
    final sideLeft = parts[0] == _uid;
    final readerUid = (d['readerUid'] as String?) ?? parts[0];
    final round = (d['round'] as num?)?.toInt() ?? 1;
    final phase = (d['phase'] as String?) ?? 'reading';
    if (phase == 'completed' && _savedCompletedRoom != widget.roomId) {
      _savedCompletedRoom = widget.roomId;
      WidgetsBinding.instance.addPostFrameCallback((_) => _saveMyResult(d));
    }
    final sharedPick = Map<String, dynamic>.from(
      (d['sharedPick'] as Map?) ?? (picks[readerUid] as Map),
    );
    final sections = List<Map<String, dynamic>>.from(
      (sharedPick['sections'] as List).map((e) => Map<String, dynamic>.from(e as Map)),
    );
    final sectionIndex = (d['sectionIndex'] as num?)?.toInt() ?? 0;
    final scoreMap = Map<String, dynamic>.from((d['scores'] as Map?) ?? {});

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(
          children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: AppColors.navyLight,
              child: Text(
                pName.isEmpty ? '?' : pName[0].toUpperCase(),
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: AppColors.gold),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(pName,
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w800)),
                  Text(
                    partnerIn ? "Xonada" : "Ulanmoqda...",
                    style: TextStyle(
                        color: partnerIn
                            ? Colors.greenAccent
                            : AppColors.goldLight),
                  ),
                ],
              ),
            ),
            PopupMenuButton<String>(
              tooltip: 'Xavfsizlik',
              onSelected: (value) => _partnerSafetyAction(value, partner, pName),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'report', child: Text('Shikoyat qilish')),
                PopupMenuItem(value: 'block', child: Text('Foydalanuvchini bloklash')),
              ],
              icon: const Icon(Icons.more_vert, color: AppColors.textDim),
            ),
          ],
        ),
        const SizedBox(height: 18),
        _voicePanel(_voice!),
        const SizedBox(height: 18),
        _pickCard("Sizning mavzuingiz", mine),
        _pickCard("$pName mavzusi", theirs),
        _studyRoundCard(
          round: round,
          phase: phase,
          readerUid: readerUid,
          partnerUid: partner,
          sectionIndex: sectionIndex,
          sections: sections,
          sharedPick: sharedPick,
          scores: scoreMap,
          names: names,
        ),
      ],
    );
  }


  Widget _studyRoundCard({
    required int round,
    required String phase,
    required String readerUid,
    required String partnerUid,
    required int sectionIndex,
    required List<Map<String, dynamic>> sections,
    required Map<String, dynamic> sharedPick,
    required Map<String, dynamic> scores,
    required Map<String, dynamic> names,
  }) {
    final isReader = readerUid == _uid;
    final listenerUid = readerUid == _uid ? partnerUid : _uid;
    final readerName = (names[readerUid] ?? "O‘quvchi") as String;
    final listenerName = (names[listenerUid] ?? 'Tinglovchi') as String;
    final myScore = (scores[_uid] as num?)?.toInt() ?? 0;
    final theirScore = (scores[partnerUid] as num?)?.toInt() ?? 0;
    final safeIndex = sections.isEmpty ? 0 : sectionIndex.clamp(0, sections.length - 1).toInt();
    final section = sections.isEmpty ? <String, dynamic>{} : sections[safeIndex];
    final title = (section['title'] ?? 'Mavzu bo‘limi') as String;
    final text = (section['text'] ?? '') as String;
    final bookTitle = (sharedPick['bookTitle'] ?? '') as String;
    final topicTitle = (sharedPick['topicTitle'] ?? '') as String;

    Widget action(String label, VoidCallback onPressed, {bool secondary = false}) =>
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: secondary ? AppColors.navyLight : AppColors.gold,
              foregroundColor: secondary ? AppColors.textMain : AppColors.black,
              padding: const EdgeInsets.symmetric(vertical: 15),
            ),
            onPressed: onPressed,
            child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
        );

    Future<void> run(Future<void> Function() task) async {
      try {
        await task();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(friendlyError(e))),
          );
        }
      }
    }

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.navy,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.goldBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.auto_stories_rounded, color: AppColors.gold),
            const SizedBox(width: 8),
            Expanded(child: Text('ROUND $round · ${sections.isEmpty ? 0 : sectionIndex + 1}/${sections.length}',
              style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900))),
            Text('Siz: $myScore  ·  Sherik: $theirScore',
              style: const TextStyle(color: AppColors.textDim, fontSize: 11)),
          ]),
          const SizedBox(height: 12),
          Text(bookTitle, style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
          Text(topicTitle, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          const SizedBox(height: 12),
          if (phase == 'completed') ...[
            const Icon(Icons.emoji_events_rounded, color: AppColors.gold, size: 44),
            const SizedBox(height: 8),
            const Text('Ikkala round ham yakunlandi!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text('Natija: ${names[_uid] ?? "Siz"} — $myScore ball, '
              '${names[partnerUid] ?? "Sherik"} — $theirScore ball.',
              style: const TextStyle(color: AppColors.textDim, height: 1.5)),
          ] else ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: AppColors.navyLight,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                phase == 'reading'
                  ? (isReader ? 'SIZ O‘QIYSIZ. Matnni ovoz chiqarib o‘qing.' : '$readerName o‘qiyapti. Diqqat bilan tinglang.')
                  : phase == 'reciting'
                    ? (isReader ? '$listenerName eshitganlarini aytib bermoqda. Tinglang.' : 'Endi eshitganlaringizni o‘z so‘zingiz bilan aytib bering.')
                    : (isReader ? '$listenerName javob berdi. To‘g‘ri yoki xato deb baholang.' : '$readerName javobingizni baholamoqda.'),
                style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4),
              ),
            ),
            const SizedBox(height: 14),
            if (isReader && phase != 'completed') ...[
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.goldLight)),
              const SizedBox(height: 8),
              if (phase == 'reading')
                SelectableText(text, style: const TextStyle(height: 1.65, fontSize: 15))
              else if (phase == 'reciting')
                const Text('Sherigingiz tugatishini kuting. U “Javob berdim” tugmasini bosadi.',
                  style: TextStyle(color: AppColors.textDim, height: 1.5))
              else ...[
                const Text('Sherigingiz aytgan ma’lumotlarni baholang:',
                  style: TextStyle(color: AppColors.textDim)),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                    onPressed: () => run(() => StudyRoundService.instance.gradeAnswer(widget.roomId, correct: true)),
                    icon: const Icon(Icons.check_rounded), label: const Text('To‘g‘ri'))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
                    onPressed: () => run(() => StudyRoundService.instance.gradeAnswer(widget.roomId, correct: false)),
                    icon: const Icon(Icons.close_rounded), label: const Text('Xato'))),
                ]),
              ],
            ] else ...[
              Text(phase == 'reading'
                ? 'Matn sizga ko‘rsatilmaydi. Ovoz orqali eslab qoling.'
                : phase == 'reciting'
                  ? 'Eshitganlaringizni sherigingizga aytib bering. Tugagach belgilang.'
                  : 'Sherigingiz javobingizni baholayapti.',
                style: const TextStyle(color: AppColors.textDim, height: 1.5)),
            ],
            const SizedBox(height: 14),
            if (phase == 'reading' && isReader)
              action('O‘qib bo‘ldim', () => run(() => StudyRoundService.instance.markReadDone(widget.roomId)))
            else if (phase == 'reciting' && !isReader)
              action('Javob berdim', () => run(() => StudyRoundService.instance.markRecited(widget.roomId)))
            else if (phase == 'grading' && !isReader)
              action('Baholash kutilmoqda...', () {}, secondary: true),
          ],
          const SizedBox(height: 10),
          Text('O‘quvchi: $readerName  ·  Tinglovchi: $listenerName',
            style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
          if (round == 2 && phase != 'completed')
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('2-round: rollar almashdi.',
                style: TextStyle(color: AppColors.goldLight, fontSize: 12)),
            ),
        ],
      ),
    );
  }

  // ---------- ovoz paneli ----------

  Widget _voicePanel(VoiceService v) {
    return AnimatedBuilder(
      animation: v,
      builder: (context, _) {
        final (icon, text, color) = switch (v.status) {
          VoiceStatus.idle || VoiceStatus.requesting => (
              Icons.hourglass_top_rounded,
              "Mikrofon tayyorlanmoqda...",
              AppColors.goldLight
            ),
          VoiceStatus.micDenied => (
              Icons.mic_off_rounded,
              "Mikrofonga ruxsat berilmagan",
              Colors.redAccent
            ),
          VoiceStatus.connecting => (
              Icons.sync_rounded,
              "Ovozli aloqa o'rnatilmoqda...",
              AppColors.goldLight
            ),
          VoiceStatus.connected => (
              Icons.graphic_eq_rounded,
              "Ovozli aloqa ulandi",
              Colors.greenAccent
            ),
          VoiceStatus.unstable => (
              Icons.signal_wifi_statusbar_connected_no_internet_4_rounded,
              "Aloqa beqaror...",
              Colors.orangeAccent
            ),
          VoiceStatus.failed => (
              Icons.error_outline_rounded,
              "Aloqa uzildi",
              Colors.redAccent
            ),
        };
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.navy,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.goldBorder),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Icon(icon, color: color),
                  const SizedBox(width: 10),
                  Expanded(
                      child: Text(text,
                          style: TextStyle(
                              color: color, fontWeight: FontWeight.w700))),
                ],
              ),
              if (v.status == VoiceStatus.micDenied) ...[
                const SizedBox(height: 10),
                const Text(
                  "Ovozli suhbat uchun mikrofon kerak. Ruxsat bering va qayta urining.",
                  style: TextStyle(color: AppColors.textDim),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    OutlinedButton(
                        onPressed: openAppSettings,
                        child: const Text("Sozlamalar")),
                    const SizedBox(width: 10),
                    FilledButton(
                      style: FilledButton.styleFrom(
                          backgroundColor: AppColors.gold,
                          foregroundColor: AppColors.black),
                      onPressed: () => v.start(v.attempt),
                      child: const Text("Qayta urinish"),
                    ),
                  ],
                ),
              ],
              if (v.status == VoiceStatus.failed) ...[
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerLeft,
                  child: FilledButton.icon(
                    style: FilledButton.styleFrom(
                        backgroundColor: AppColors.gold,
                        foregroundColor: AppColors.black),
                    onPressed: _reconnect,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text("Qayta ulanish"),
                  ),
                ),
              ],
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _roundBtn(
                    v.micOn ? Icons.mic_rounded : Icons.mic_off_rounded,
                    v.micOn ? "Mikrofon" : "O'chiq",
                    active: v.micOn,
                    onTap: () => v.setMic(!v.micOn),
                  ),
                  _roundBtn(
                    v.speakerOn
                        ? Icons.volume_up_rounded
                        : Icons.hearing_rounded,
                    v.speakerOn ? "Karnay" : "Quloqchin",
                    active: v.speakerOn,
                    onTap: () => v.setSpeaker(!v.speakerOn),
                  ),
                  _roundBtn(
                    Icons.call_end_rounded,
                    "Tugatish",
                    danger: true,
                    onTap: _confirmEnd,
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  const Icon(Icons.volume_down_rounded,
                      color: AppColors.textDim),
                  Expanded(
                    child: Slider(
                      value: v.volume,
                      min: 0,
                      max: 2,
                      activeColor: AppColors.gold,
                      onChanged: v.setVolume,
                    ),
                  ),
                  SizedBox(
                    width: 48,
                    child: Text("${(v.volume * 100).round()}%",
                        textAlign: TextAlign.right,
                        style: const TextStyle(color: AppColors.textDim)),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _roundBtn(IconData icon, String label,
      {required VoidCallback onTap, bool active = true, bool danger = false}) {
    final bg = danger
        ? Colors.redAccent
        : (active ? AppColors.gold : AppColors.navyLight);
    final fg = danger || active ? AppColors.black : AppColors.textMain;
    return Column(
      children: [
        Material(
          color: bg,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(
              width: 62,
              height: 62,
              child: Icon(icon, color: fg, size: 28),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(label,
            style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
      ],
    );
  }

  Widget _pickCard(String label, Map<String, dynamic> p) {
    final n = (p['sections'] as List).length;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.navy,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.goldBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
          const SizedBox(height: 4),
          Text("${p['bookTitle']}",
              style: const TextStyle(fontWeight: FontWeight.w700)),
          Text("${p['topicTitle']} · $n ta bo'lim",
              style: const TextStyle(color: AppColors.goldLight)),
        ],
      ),
    );
  }
}
