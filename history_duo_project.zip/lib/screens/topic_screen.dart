import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/book.dart';

/// Mavzu bo'limlarini ko'rish (o'qib chiqish uchun).
class TopicScreen extends StatelessWidget {
  final Book book;
  final Topic topic;
  const TopicScreen({super.key, required this.book, required this.topic});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(topic.title)),
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
            itemCount: topic.sections.length,
            itemBuilder: (context, i) {
              final s = topic.sections[i];
              return Container(
                margin: const EdgeInsets.only(bottom: 14),
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppColors.navy,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.goldBorder),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 14,
                          backgroundColor: AppColors.gold,
                          child: Text("${i + 1}",
                              style: const TextStyle(
                                  color: AppColors.black,
                                  fontWeight: FontWeight.w800)),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(s.title,
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w700)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(s.text,
                        style: const TextStyle(fontSize: 16, height: 1.5)),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
