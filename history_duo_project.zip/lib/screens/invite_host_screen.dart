import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/theme.dart';
import '../models/book.dart';
import '../services/auth_service.dart';
import '../services/match_service.dart';
import '../widgets/animated_helpers.dart';
import '../widgets/pulse_radar.dart';
import 'room_screen.dart';

/// Do'st uchun kod yaratib, uning ulanishini kutadi.
class InviteHostScreen extends StatefulWidget {
  final TopicSelection selection;
  const InviteHostScreen({super.key, required this.selection});

  @override
  State<InviteHostScreen> createState() => _InviteHostScreenState();
}

class _InviteHostScreenState extends State<InviteHostScreen> {
  String? _code;
  String? _error;
  bool _offline = false;
  bool _matched = false;
  Timer? _timer;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _sub;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      final code = await MatchService.instance.createInvite(widget.selection);
      if (!mounted) {
        MatchService.instance.deleteInvite(code);
        return;
      }
      setState(() => _code = code);
      _sub = MatchService.instance.inviteStream(code).listen((s) {
        final r = s.data()?['roomId'];
        if (r != null) _enter(r as String);
      }, onError: (_) {});
      _timer = Timer.periodic(const Duration(seconds: 10), (_) async {
        try {
          await MatchService.instance.inviteHeartbeat(code);
          if (mounted && _offline) setState(() => _offline = false);
        } catch (_) {
          if (mounted) setState(() => _offline = true);
        }
      });
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  void _enter(String roomId) {
    if (_matched) return;
    _matched = true;
    _timer?.cancel();
    _sub?.cancel();
    if (_code != null) MatchService.instance.deleteInvite(_code!);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => RoomScreen(roomId: roomId)));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _sub?.cancel();
    if (!_matched && _code != null) MatchService.instance.deleteInvite(_code!);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Do'st bilan ulanish")),
      body: Container(
        decoration: appBackground,
        width: double.infinity,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                if (_offline)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0x33FF5252),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Text(
                        "Internet aloqasi yo'q. Kod faqat aloqa tiklangach ishlaydi."),
                  ),
                const Spacer(),
                const PulseRadar(icon: Icons.group_add_rounded),
                const SizedBox(height: 24),
                if (_error != null)
                  Text(_error!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.redAccent))
                else if (_code == null)
                  const CircularProgressIndicator(color: AppColors.gold)
                else ...[
                  const Text("Do'stingizga shu kodni yuboring",
                      style: TextStyle(color: AppColors.textDim)),
                  const SizedBox(height: 10),
                  GestureDetector(
                    onTap: () {
                      Clipboard.setData(ClipboardData(text: _code!));
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Kod nusxalandi")));
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.navy,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppColors.gold),
                      ),
                      child: Text(_code!,
                          style: const TextStyle(
                              fontSize: 38,
                              letterSpacing: 8,
                              fontWeight: FontWeight.w800,
                              color: AppColors.gold)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text("Nusxalash uchun kodni bosing",
                      style:
                          TextStyle(color: AppColors.textDim, fontSize: 12)),
                  const SizedBox(height: 16),
                  const Text("Do'stingiz ulanishini kutyapmiz...",
                      style: TextStyle(fontSize: 16)),
                ],
                const Spacer(),
                PressScale(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    height: 54,
                    width: double.infinity,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.redAccent),
                    ),
                    child: const Text("Bekor qilish",
                        style: TextStyle(
                            color: Colors.redAccent,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
