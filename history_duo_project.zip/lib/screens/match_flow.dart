import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../services/match_service.dart';
import 'room_screen.dart';

/// Foydalanuvchi allaqachon faol xonada bo'lsa, unga qaytaradi.
/// true qaytarsa - yangi ulanish boshlanmasligi kerak.
Future<bool> resumeActiveRoom(BuildContext context) async {
  try {
    final id = await MatchService.instance.activeRoomId();
    if (id == null) return false;
    if (!context.mounted) return true;
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Siz faol xonadasiz, unga qaytyapsiz")));
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => RoomScreen(roomId: id)));
    return true;
  } catch (e) {
    if (context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(friendlyError(e))));
    }
    return true;
  }
}
