import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Hali ulanmagan bo'limlar uchun halol ekran.
class ComingSoonScreen extends StatelessWidget {
  final String title;
  final IconData icon;
  final int stage;
  const ComingSoonScreen({
    super.key,
    required this.title,
    required this.icon,
    required this.stage,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Container(
        decoration: appBackground,
        width: double.infinity,
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 72, color: AppColors.gold),
            const SizedBox(height: 24),
            Text(title,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Text(
              "Bu bo'lim $stage-bosqichda ishga tushiriladi.",
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textDim, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}
