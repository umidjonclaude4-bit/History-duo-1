import 'package:flutter/material.dart';
import '../core/theme.dart';

class HistoryDuoLogo extends StatelessWidget {
  final double size;
  const HistoryDuoLogo({super.key, this.size = 110});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.navyLight, AppColors.black],
            ),
            border: Border.all(color: AppColors.gold, width: 2.5),
            boxShadow: const [
              BoxShadow(
                color: Color(0x55D4AF37),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Icon(Icons.account_balance_rounded,
                  size: size * 0.46, color: AppColors.gold),
              Positioned(
                bottom: size * 0.14,
                child: Icon(Icons.graphic_eq_rounded,
                    size: size * 0.22, color: AppColors.goldLight),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        ShaderMask(
          shaderCallback: (rect) => const LinearGradient(
            colors: [AppColors.goldLight, AppColors.gold],
          ).createShader(rect),
          child: Text(
            'HISTORY DUO',
            style: TextStyle(
              fontSize: size * 0.27,
              fontWeight: FontWeight.w800,
              letterSpacing: 4,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}
