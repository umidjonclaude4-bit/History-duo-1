import 'package:flutter/material.dart';

class AppColors {
  static const black = Color(0xFF0A0A0F);
  static const navy = Color(0xFF0B1B3A);
  static const navyLight = Color(0xFF13294F);
  static const gold = Color(0xFFD4AF37);
  static const goldLight = Color(0xFFF1D77A);
  static const textMain = Color(0xFFF5F1E6);
  static const textDim = Color(0xFF9AA5B8);
  static const goldBorder = Color(0x55D4AF37);
}

ThemeData buildAppTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.gold,
    brightness: Brightness.dark,
  ).copyWith(
    primary: AppColors.gold,
    surface: AppColors.navy,
  );
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.black,
    textTheme: ThemeData.dark().textTheme.apply(
          bodyColor: AppColors.textMain,
          displayColor: AppColors.textMain,
        ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      foregroundColor: AppColors.textMain,
    ),
  );
}

const appBackground = BoxDecoration(
  gradient: LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [AppColors.navy, AppColors.black],
  ),
);
