import 'dart:async';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../core/errors.dart';
import '../models/book.dart';

class _NoMatch implements Exception {}

class _Cand {
  final String id;
  final int score;
  final DateTime created;
  _Cand(this.id, this.score, this.created);
}

/// Tasodifiy sherik (navbat) va do'st taklifi (kod) orqali xona yaratish.
///
/// queue/{uid}   - kutayotgan foydalanuvchi (heartbeat: lastSeen)
/// invites/{code} - do'st taklifi
/// rooms/{id}    - ikki kishilik xona
class MatchService {
  MatchService._();
  static final MatchService instance = MatchService._();

  static const _net = Duration(seconds: 10);
  static const _freshSeconds = 40;
  static const _staleSeconds = 130;

  FirebaseFirestore get _db => FirebaseFirestore.instance;
  String get _uid => FirebaseAuth.instance.currentUser!.uid;
  GetOptions get _srv => GetOptions(source: Source.server);

  DocumentReference<Map<String, dynamic>> get _queueRef =>
      _db.collection('queue').doc(_uid);
  DocumentReference<Map<String, dynamic>> get _userRef =>
      _db.collection('users').doc(_uid);
  CollectionReference<Map<String, dynamic>> get _rooms =>
      _db.collection('rooms');
  CollectionReference<Map<String, dynamic>> get _invites =>
      _db.collection('invites');

  // ---------- umumiy ----------

  Map<String, dynamic> _pick(TopicSelection s) => {
        'bookId': s.book.id,
        'bookTitle': s.book.title,
        'topicId': s.topic.id,
        'topicTitle': s.topic.title,
        'sections': s.topic.sections.map((x) => x.toMap()).toList(),
      };

  Future<Map<String, dynamic>> _entry(TopicSelection sel) async {
    final u = await _userRef.get(_srv).timeout(_net);
    final d = u.data();
    if (d == null) {
      throw const UserFacingException("Profil topilmadi. Qayta kiring");
    }
    return {
      'uid': _uid,
      'displayName': d['displayName'] ?? '',
      'ageGroup': d['ageGroup'] ?? 'adult',
      'pick': _pick(sel),
      'roomId': null,
      'createdAt': FieldValue.serverTimestamp(),
      'lastSeen': FieldValue.serverTimestamp(),
    };
  }

  /// participants[0] - chapdagi (1-roundda o'qiydi), participants[1] - o'ngdagi.
  Map<String, dynamic> _roomData(
      Map<String, dynamic> a, Map<String, dynamic> b) {
    final first = Random().nextBool();
    final x = first ? a : b;
    final y = first ? b : a;
    final xu = x['uid'] as String;
    final yu = y['uid'] as String;
    return {
      'participants': [xu, yu],
      'names': {xu: x['displayName'], yu: y['displayName']},
      'picks': {xu: x['pick'], yu: y['pick']},
      'sharedPick': x['pick'],
      'scores': {xu: 0, yu: 0},
      'ageGroup': a['ageGroup'],
      'status': 'active',
      'round': 1,
      'phase': 'reading',
      'sectionIndex': 0,
      'readerUid': xu,
      'joined': <String, dynamic>{},
      'endedBy': null,
      'createdAt': FieldValue.serverTimestamp(),
    };
  }

  // ---------- faol xona (bir foydalanuvchi - bitta xona) ----------

  Future<String?> activeRoomId() async {
    final u = await _userRef.get(_srv).timeout(_net);
    final rid = u.data()?['currentRoomId'] as String?;
    if (rid == null) return null;
    try {
      final r = await _rooms.doc(rid).get(_srv).timeout(_net);
      final d = r.data();
      if (d != null &&
          d['status'] == 'active' &&
          (d['participants'] as List).contains(_uid)) {
        return rid;
      }
    } on FirebaseException catch (e) {
      if (e.code != 'permission-denied' && e.code != 'not-found') rethrow;
    }
    await _userRef.update({'currentRoomId': null});
    return null;
  }

  Future<void> enterRoom(String roomId) async {
    await _userRef.update({'currentRoomId': roomId});
    await _rooms.doc(roomId).update({'joined.$_uid': true});
  }

  Future<void> leaveRoom(String roomId) async {
    try {
      await _userRef.update({'currentRoomId': null}).timeout(_net);
    } catch (_) {}
  }

  Future<void> endRoom(String roomId) {
    return _rooms.doc(roomId).update({
      'status': 'ended',
      'endedBy': _uid,
      'endedAt': FieldValue.serverTimestamp(),
    }).timeout(_net);
  }

  // ---------- tasodifiy navbat ----------

  Future<void> joinQueue(TopicSelection sel) async {
    final e = await _entry(sel);
    await _queueRef.set(e).timeout(_net);
  }

  Future<void> heartbeat() {
    return _queueRef
        .update({'lastSeen': FieldValue.serverTimestamp()}).timeout(_net);
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> queueStream() =>
      _queueRef.snapshots();

  Future<void> leaveQueue() async {
    try {
      await _queueRef.delete().timeout(_net);
    } catch (_) {}
  }

  /// Mos sherik topsa xona yaratadi va roomId qaytaradi.
  Future<String?> findAndMatch() async {
    final me = await _queueRef.get(_srv).timeout(_net);
    final mine = me.data();
    if (mine == null) {
      throw const UserFacingException("Navbat yozuvi topilmadi");
    }
    if (mine['roomId'] != null) return mine['roomId'] as String;
    final refTime = (mine['lastSeen'] as Timestamp?)?.toDate();
    if (refTime == null) return null;

    final myUser = await _userRef.get(_srv).timeout(_net);
    final myBlocked =
        List<String>.from((myUser.data()?['blocked'] as List?) ?? const []);
    final myPick = Map<String, dynamic>.from(mine['pick'] as Map);

    final snap = await _db
        .collection('queue')
        .where('ageGroup', isEqualTo: mine['ageGroup'])
        .limit(40)
        .get(_srv)
        .timeout(_net);

    final cands = <_Cand>[];
    for (final d in snap.docs) {
      if (d.id == _uid || myBlocked.contains(d.id)) continue;
      final data = d.data();
      if (data['roomId'] != null) continue;
      final p = Map<String, dynamic>.from(data['pick'] as Map);
      // Bir xonada ikkala odam aynan bir xil kitob va mavzuni o'rganadi.
      if (p['bookId'] != myPick['bookId'] || p['topicId'] != myPick['topicId']) continue;
      final seen = (data['lastSeen'] as Timestamp?)?.toDate();
      if (seen == null) continue;
      final age = refTime.difference(seen).inSeconds;
      if (age > _staleSeconds) {
        d.reference.delete().catchError((_) {});
        continue;
      }
      if (age > _freshSeconds) continue;
      var score = 0;
      if (p['bookId'] == myPick['bookId']) score += 1;
      if (p['topicId'] == myPick['topicId']) score += 1;
      final created = (data['createdAt'] as Timestamp?)?.toDate() ?? seen;
      cands.add(_Cand(d.id, score, created));
    }
    cands.sort((a, b) {
      final s = b.score.compareTo(a.score);
      return s != 0 ? s : a.created.compareTo(b.created);
    });

    for (final c in cands.take(3)) {
      try {
        final u = await _db
            .collection('users')
            .doc(c.id)
            .get(_srv)
            .timeout(_net);
        final theirBlocked =
            List<String>.from((u.data()?['blocked'] as List?) ?? const []);
        if (theirBlocked.contains(_uid)) continue;
      } on FirebaseException catch (_) {
        continue;
      }
      try {
        return await _matchTx(c.id);
      } catch (e) {
        if (e is FirebaseException || e is TimeoutException) rethrow;
        continue; // boshqasi band qildi
      }
    }
    return null;
  }

  Future<String> _matchTx(String candId) async {
    final candRef = _db.collection('queue').doc(candId);
    final roomRef = _rooms.doc();
    await _db.runTransaction((tx) async {
      final a = await tx.get(_queueRef);
      final b = await tx.get(candRef);
      final ad = a.data();
      final bd = b.data();
      if (ad == null || ad['roomId'] != null) throw _NoMatch();
      if (bd == null || bd['roomId'] != null) throw _NoMatch();
      tx.set(roomRef, _roomData(ad, bd));
      tx.update(candRef, {'roomId': roomRef.id});
      tx.update(_queueRef, {'roomId': roomRef.id});
    }).timeout(_net);
    return roomRef.id;
  }

  // ---------- do'st taklifi (kod) ----------

  Future<String> createInvite(TopicSelection sel) async {
    final e = await _entry(sel);
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final rnd = Random.secure();
    for (var i = 0; i < 5; i++) {
      final code =
          List.generate(6, (_) => chars[rnd.nextInt(chars.length)]).join();
      final ref = _invites.doc(code);
      final ex = await ref.get(_srv).timeout(_net);
      if (ex.exists) continue;
      await ref.set(e).timeout(_net);
      return code;
    }
    throw const UserFacingException("Kod yaratib bo'lmadi, qayta urining");
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> inviteStream(String code) =>
      _invites.doc(code).snapshots();

  Future<void> inviteHeartbeat(String code) {
    return _invites
        .doc(code)
        .update({'lastSeen': FieldValue.serverTimestamp()}).timeout(_net);
  }

  Future<void> deleteInvite(String code) async {
    try {
      await _invites.doc(code).delete().timeout(_net);
    } catch (_) {}
  }

  Future<String> joinInvite(String code, TopicSelection sel) async {
    final mine = await _entry(sel);
    final ref = _invites.doc(code);
    final pre = await ref.get(_srv).timeout(_net);
    final d = pre.data();
    if (d == null) throw const UserFacingException("Bunday kod topilmadi");
    if (d['roomId'] != null) {
      throw const UserFacingException("Bu kod allaqachon ishlatilgan");
    }
    if (d['uid'] == _uid) {
      throw const UserFacingException("Bu sizning o'z kodingiz");
    }
    if (d['ageGroup'] != mine['ageGroup']) {
      throw const UserFacingException(
          "Xavfsizlik uchun faqat bir xil yosh guruhidagilar ulana oladi");
    }
    final theirPick = Map<String, dynamic>.from(d['pick'] as Map);
    final myPick = Map<String, dynamic>.from(mine['pick'] as Map);
    if (theirPick['bookId'] != myPick['bookId'] || theirPick['topicId'] != myPick['topicId']) {
      throw const UserFacingException(
          "Ikkalangiz ham bir xil kitob va mavzuni tanlashingiz kerak");
    }
    final roomRef = _rooms.doc();
    try {
      await _db.runTransaction((tx) async {
        final s = await tx.get(ref);
        final data = s.data();
        if (data == null || data['roomId'] != null) throw _NoMatch();
        tx.set(roomRef, _roomData(data, mine));
        tx.update(ref, {'roomId': roomRef.id});
      }).timeout(_net);
    } on FirebaseException catch (e) {
      if (e.code == 'permission-denied') {
        throw const UserFacingException(
            "Taklif eskirgan. Do'stingizdan yangi kod so'rang");
      }
      rethrow;
    } on TimeoutException {
      rethrow;
    } catch (_) {
      throw const UserFacingException("Bu kod band yoki eskirgan");
    }
    return roomRef.id;
  }
}
